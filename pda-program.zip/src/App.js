import './App.css';
import { useState, useEffect } from 'react';
import { Connection, PublicKey, clusterApiUrl } from '@solana/web3.js';
import {
  Program, AnchorProvider, web3
} from '@project-serum/anchor';
import idl from './idl.json';

import { PhantomWalletAdapter } from '@solana/wallet-adapter-wallets';
import { useWallet, WalletProvider, ConnectionProvider } from '@solana/wallet-adapter-react';
import { WalletModalProvider, WalletMultiButton } from '@solana/wallet-adapter-react-ui';
require('@solana/wallet-adapter-react-ui/styles.css');

const wallets = [
  /* view list of available wallets at https://github.com/solana-labs/wallet-adapter#wallets */
  new PhantomWalletAdapter()
]

const { SystemProgram, Keypair } = web3;
/* create an account  */
const baseAccount = Keypair.generate();
const opts = {
  preflightCommitment: "processed"
}
const programID = new PublicKey(idl.metadata.address);

const network = clusterApiUrl('devnet');

function App() {
  const [data, setData] = useState();
  const [value, setValue] = useState('red');
  const [updateValue, setUpdateValue] = useState();
  const [balance, setBalance] = useState();
  const wallet = useWallet();
  
  async function getProvider() {
    /* create the provider and return it to the caller */
    /* network set to local network for now */
    const network = clusterApiUrl('devnet');
    const connection = new Connection(network, opts.preflightCommitment);
    console.log(connection);
    const provider = new AnchorProvider(
      connection, wallet, opts.preflightCommitment,
    );
    return provider;
  }

  async function derivePda(color, pubkey) {
    let [pda, _] = await PublicKey.findProgramAddress(
      [
        pubkey.toBuffer(),
        Buffer.from("_"),
        Buffer.from(color),
      ],
      programID
    );

    return pda;
  }

  async function createLedgerAccount(color) {
    const provider = await getProvider();
    let pda = await derivePda(color, provider.wallet.publicKey);

    /* create the program interface combining the idl, program ID, and provider */
    const program = new Program(idl, programID, provider);

    try {
      /* interact with the program via rpc */
      await program.methods.createLedger(color)
      .accounts({
        ledgerAccount: pda,
        wallet: provider.wallet.publicKey,
        SystemProgram: SystemProgram.programId,
      })
      .rpc();

      let dataHis = await program.account.ledger.all()
      setData(dataHis);
    } catch (err) {
      console.log("Transaction error: ", err);
    }
  }

  async function editLedgerAccount(color, balance) {
    const provider = await getProvider();
    
    /* create the program interface combining the idl, program ID, and provider */
    const program = new Program(idl, programID, provider);

    const selectedLedger = data.filter(ledger => ledger.account.color === color);
    console.log(balance);
    try { 
      await program.methods.modifyLedger(balance)
      .accounts({
        ledgerAccount: selectedLedger[0].publicKey,
        wallet: provider.wallet.publicKey,
      })
      .rpc();

      const dataHis = await program.account.ledger.all()
      setData(dataHis);
    } catch (err) {
      console.log("Transaction error: ", err);
    }
  }

  const fetchData = async () => {
    const provider = await getProvider();
    /* create the program interface combining the idl, program ID, and provider */
    const program = new Program(idl, programID, provider);

    let dataHis = await program.account.ledger.all()
    setData(dataHis);
  }

  useEffect(() => {  
    fetchData();
  }, [])
  

  if (!wallet.connected) {
    /* If the user's wallet is not connected, display connect wallet button. */
    return (
      <div style={{ display: 'flex', justifyContent: 'center', marginTop:'100px' }}>
        <WalletMultiButton />
      </div>
    )
  } else {
    return (
      <div className="App">
        <div className='create-ledger'>
          <h3>Create Leader</h3>
          <input type='text' placeholder='color' value={value} onChange={(e) => setValue(e.target.value)}/>
          <button onClick={() => createLedgerAccount(value)}>Create Ledger</button>
        </div>

        <div className='update-ledger'>
          <h3>Update Leader</h3>
          <input type='text' placeholder='color' value={updateValue} onChange={(e) => setUpdateValue(e.target.value)}/>
          <input type='text' placeholder='number' value={balance} onChange={(e) => setBalance(e.target.value)}/>
          <button onClick={() => editLedgerAccount(updateValue, balance)}>Edit Ledger</button>
        </div>

        <div className='data-list'>
          <h3>Data List</h3>
          {
            data ? (
              data.map((ledger, index) => (
                <div className='ledger' key={index}>
                  <span>Color:{ledger.account.color}</span>
                  <span style={{width: '20px', display: 'inline-block'}}></span>
                  <span>Balance:{ledger.account.balance}</span>
                  <br/>
                </div>
              ))
            ) : null
          }
        </div>
      </div>
    );
  }
}

/* wallet configuration as specified here: https://github.com/solana-labs/wallet-adapter#setup */
const AppWithProvider = () => (
  <ConnectionProvider endpoint={network}>
    <WalletProvider wallets={wallets} autoConnect>
      <WalletModalProvider>
        <App />
      </WalletModalProvider>
    </WalletProvider>
  </ConnectionProvider>
)

export default AppWithProvider;